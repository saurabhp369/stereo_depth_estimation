Copy the data folder
Ensure that the folder structure is :
    spalande_proj3
        --data
            --curule
            --octagon
            --pendulum
        --Utils
        --stereo_vision.py 
        --Readme.md
        --Report.pdf


To run the code
    python3 stereo_vision.py